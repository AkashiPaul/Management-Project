package net.javaguides.springboot;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ResearchRepository extends JpaRepository<Research,Long> {
	
	public Optional<Research> findById(Long id);

}


