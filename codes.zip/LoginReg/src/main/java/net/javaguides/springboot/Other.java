package net.javaguides.springboot;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table
public class Other {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	 private String Responsibilities_Other_than_Teaching;
	 private String Awards;
	 private  String Honours;
	 private String Recognition;
	 private String Membership;
	 private String Fellowship;
	 private String  National_Collaboration;
	 private String  Interational_Collaboration;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getResponsibilities_Other_than_Teaching() {
		return Responsibilities_Other_than_Teaching;
	}
	public void setResponsibilities_Other_than_Teaching(String responsibilities_Other_than_Teaching) {
		Responsibilities_Other_than_Teaching = responsibilities_Other_than_Teaching;
	}
	public String getAwards() {
		return Awards;
	}
	public void setAwards(String awards) {
		Awards = awards;
	}
	public String getHonours() {
		return Honours;
	}
	public void setHonours(String honours) {
		Honours = honours;
	}
	public String getRecognition() {
		return Recognition;
	}
	public void setRecognition(String recognition) {
		Recognition = recognition;
	}
	public String getMembership() {
		return Membership;
	}
	public void setMembership(String membership) {
		Membership = membership;
	}
	public String getFellowship() {
		return Fellowship;
	}
	public void setFellowship(String fellowship) {
		Fellowship = fellowship;
	}
	public String getNational_Collaboration() {
		return National_Collaboration;
	}
	public void setNational_Collaboration(String national_Collaboration) {
		National_Collaboration = national_Collaboration;
	}
	public String getInterational_Collaboration() {
		return Interational_Collaboration;
	}
	public void setInterational_Collaboration(String interational_Collaboration) {
		Interational_Collaboration = interational_Collaboration;
	}
	
	 
}
