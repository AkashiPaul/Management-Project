package net.javaguides.springboot;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PatentRepository extends JpaRepository<Patent, Long> {
	
	public Optional<Patent> findById(Long id);

}
