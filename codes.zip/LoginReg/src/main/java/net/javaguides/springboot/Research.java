package net.javaguides.springboot;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table
public class Research {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	  private Long basic_research;
	  private Long applied_research;
	  private Long action_research;
	  private Long project_submitted;
	  private Long ongoing_project;
	  private Long Group1_Research_paper_in_UGC_care_list_Journals;
	  private Long Group2_Research_paper_in_UGC_care_list_Journals;
	  private Long Books_Published;
	  private Long Books_chapter_Published;
	  private Long popular_articles;
	  private Long  National_Seminar_Organized;
	  private Long  International_Seminar_Organized;
	  private Long  National_Seminar_Attended;
	  private Long  InterNational_Seminar_Attended;
	  private Long  Conference_Proceedings;
	  private Long Consultancy;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getBasic_research() {
		return basic_research;
	}
	public void setBasic_research(Long basic_research) {
		this.basic_research = basic_research;
	}
	public Long getApplied_research() {
		return applied_research;
	}
	public void setApplied_research(Long applied_research) {
		this.applied_research = applied_research;
	}
	public Long getAction_research() {
		return action_research;
	}
	public void setAction_research(Long action_research) {
		this.action_research = action_research;
	}
	public Long getProject_submitted() {
		return project_submitted;
	}
	public void setProject_submitted(Long project_submitted) {
		this.project_submitted = project_submitted;
	}
	public Long getOngoing_project() {
		return ongoing_project;
	}
	public void setOngoing_project(Long ongoing_project) {
		this.ongoing_project = ongoing_project;
	}
	public Long getGroup1_Research_paper_in_UGC_care_list_Journals() {
		return Group1_Research_paper_in_UGC_care_list_Journals;
	}
	public void setGroup1_Research_paper_in_UGC_care_list_Journals(Long group1_Research_paper_in_UGC_care_list_Journals) {
		Group1_Research_paper_in_UGC_care_list_Journals = group1_Research_paper_in_UGC_care_list_Journals;
	}
	public Long getGroup2_Research_paper_in_UGC_care_list_Journals() {
		return Group2_Research_paper_in_UGC_care_list_Journals;
	}
	public void setGroup2_Research_paper_in_UGC_care_list_Journals(Long group2_Research_paper_in_UGC_care_list_Journals) {
		Group2_Research_paper_in_UGC_care_list_Journals = group2_Research_paper_in_UGC_care_list_Journals;
	}
	public Long getBooks_Published() {
		return Books_Published;
	}
	public void setBooks_Published(Long books_Published) {
		Books_Published = books_Published;
	}
	public Long getBooks_chapter_Published() {
		return Books_chapter_Published;
	}
	public void setBooks_chapter_Published(Long books_chapter_Published) {
		Books_chapter_Published = books_chapter_Published;
	}
	public Long getPopular_articles() {
		return popular_articles;
	}
	public void setPopular_articles(Long popular_articles) {
		this.popular_articles = popular_articles;
	}
	public Long getNational_Seminar_Organized() {
		return National_Seminar_Organized;
	}
	public void setNational_Seminar_Organized(Long national_Seminar_Organized) {
		National_Seminar_Organized = national_Seminar_Organized;
	}
	public Long getInternational_Seminar_Organized() {
		return International_Seminar_Organized;
	}
	public void setInternational_Seminar_Organized(Long international_Seminar_Organized) {
		International_Seminar_Organized = international_Seminar_Organized;
	}
	public Long getNational_Seminar_Attended() {
		return National_Seminar_Attended;
	}
	public void setNational_Seminar_Attended(Long national_Seminar_Attended) {
		National_Seminar_Attended = national_Seminar_Attended;
	}
	public Long getInterNational_Seminar_Attended() {
		return InterNational_Seminar_Attended;
	}
	public void setInterNational_Seminar_Attended(Long interNational_Seminar_Attended) {
		InterNational_Seminar_Attended = interNational_Seminar_Attended;
	}
	public Long getConference_Proceedings() {
		return Conference_Proceedings;
	}
	public void setConference_Proceedings(Long conference_Proceedings) {
		Conference_Proceedings = conference_Proceedings;
	}
	public Long getConsultancy() {
		return Consultancy;
	}
	public void setConsultancy(Long consultancy) {
		Consultancy = consultancy;
	}
	
}