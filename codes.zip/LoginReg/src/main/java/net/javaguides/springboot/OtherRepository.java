package net.javaguides.springboot;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OtherRepository extends JpaRepository<Other, Long> {
	
	public Optional<Other> findById(Long id);

}