package net.javaguides.springboot;

import org.springframework.data.jpa.repository.JpaRepository;


public interface TeachingRepository extends JpaRepository<Teaching, Long> {
	
	public Teaching findByUG(int ug);

}