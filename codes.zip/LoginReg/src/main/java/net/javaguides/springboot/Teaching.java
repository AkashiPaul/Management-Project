package net.javaguides.springboot;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Teaching {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	private int UG;
	private int PG_phd;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getUG() {
		return UG;
	}
	public void setUG(int uG) {
		UG = uG;
	}
	public int getPG_phd() {
		return PG_phd;
	}
	public void setPG_phd(int pG_phd) {
		PG_phd = pG_phd;
	}
	

}
