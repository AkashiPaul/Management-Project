package net.javaguides.springboot;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table
public class Patent {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	private Long patent_applied;
	private Long patent_published;
	private Long patent_granted;
	private Long   MOOC_SWAYAM_content_developed;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Long getPatent_applied() {
		return patent_applied;
	}
	public void setPatent_applied(Long patent_applied) {
		this.patent_applied = patent_applied;
	}
	public Long getPatent_published() {
		return patent_published;
	}
	public void setPatent_published(Long patent_published) {
		this.patent_published = patent_published;
	}
	public Long getPatent_granted() {
		return patent_granted;
	}
	public void setPatent_granted(Long patent_granted) {
		this.patent_granted = patent_granted;
	}
	public Long getMOOC_SWAYAM_content_developed() {
		return MOOC_SWAYAM_content_developed;
	}
	public void setMOOC_SWAYAM_content_developed(Long mOOC_SWAYAM_content_developed) {
		MOOC_SWAYAM_content_developed = mOOC_SWAYAM_content_developed;
	}
}