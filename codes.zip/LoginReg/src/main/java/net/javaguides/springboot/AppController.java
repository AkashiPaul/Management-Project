package net.javaguides.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

 
@Controller
public class AppController {
 
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private DOFRepository dofRepo;
    @Autowired
    private TeachingRepository teachRepo;
    @Autowired
    private ResearchRepository researchRepo;
    @Autowired
    private PatentRepository patentRepo;
    @Autowired
    private OtherRepository otherRepo;
    @GetMapping("/index")
    public String viewHomePage() {
        return "index";
    }
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
         
        return "register";
    }
    @PostMapping("/process_register")
    public String processRegister(User user) {
       
         
        userRepo.save(user);
         
        return "process_success";
    }
    
    @GetMapping("/Login")
    public String loginpage(Model model) {
        return "Login";
    }
    @GetMapping("/Welcome")
    public String welcome(Model model) {
    	model.addAttribute("dof",new DOF());
    	return "Welcome";
    }
   
    @PostMapping("/next_phase")
    public String nextphase(DOF dof) {
       
         
        dofRepo.save(dof);
         
        return "next_phase";
    }
    @GetMapping("/next_phase")
    public String nextphase(Model model) {
    	model.addAttribute("teach",new Teaching());
    	return "next_phase2";
    }
    @PostMapping("/next_phase1")
    public String nextphase1(Teaching teach) {
    	teachRepo.save(teach);
    	return "next_phase2";
    }
    @GetMapping("/next_phase1")
    public String nextphase1(Model model) {
    	model.addAttribute("research",new Research());
    	return "next_phase2";
    }
    @PostMapping("/phasepatent")
    public String phasepatent(Research research) {
    	researchRepo.save(research);
    	return "next_phase4";
    }
    @GetMapping("/phasepatent")
    public String phasepatent(Model model) {
    	model.addAttribute("patent",new Patent());
    	return "next_phase4";}
    @PostMapping("/phaseother")
    public String phaseother(Patent patent) {
    	patentRepo.save(patent);
    	return "next_phase6";
    }
    @GetMapping("/phaseother")
    public String phaseother(Model model) {
    	model.addAttribute("other",new Other());
    	return "next_phase6";}
    @PostMapping("/next_phasefinish")
    public String next_phasefinish(Other other) {
    	otherRepo.save(other);
    	return "finish";
    }
    
}
    
   
